# RAG Retrieval Test Report

**Release:** Zynora v1.2 · **Scope:** approved-content-only retrieval

- Retrieval is limited to `APPROVED` and `ACTIVE` documents.
- Draft and archived records are rejected by both the browser adapter and Flask service.
- Evidence includes document ID, title, category, version, source, chunk content, and score.
- Prompt-injection patterns short-circuit retrieval and return the exact fallback.
- Duplicate/irrelevant material is bounded to the strongest relevant result in the local adapter.

**Result:** PASS for the local demo path. Version conflicts and archived/draft scenarios are covered by the status transition rules and dataset Q10/Q15/Q40.
