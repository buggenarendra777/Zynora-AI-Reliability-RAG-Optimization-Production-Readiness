# Final Production AI Validation

1. Login through the new secure workspace screen.
2. Create a new conversation.
3. Ask a Zyngram question and verify source evidence.
4. Ask a contextual follow-up such as “What comes after Hub?”
5. Open previous conversation / clear / delete controls.
6. Ask an unknown question and verify the exact fallback.
7. Run prompt-injection and unauthorized-access test cases.
8. Open Monitoring and verify response counts, health, and security gates.
9. Open Knowledge admin and verify approved/active retrieval status.
10. Run `pnpm run build` before presentation.

**Release:** Zynora v1.2 local production validation package. **Rollback:** restore the prior ZIP, remove `dist/`, clear `zynora-*` local storage if testing state must be reset, and redeploy the prior commit/image.
