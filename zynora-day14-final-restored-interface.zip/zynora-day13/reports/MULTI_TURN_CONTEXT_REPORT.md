# Multi-turn Context Report

Conversations persist in browser local storage with an ID, title, message history, created/updated timestamps, and user ownership in the backend schema. New, clear, continue, and delete controls are available in the chat top bar. Follow-up requests are sent with the last 12 messages when the API adapter is enabled. A new conversation starts with an empty context. No cross-user data is copied into the local demo.
