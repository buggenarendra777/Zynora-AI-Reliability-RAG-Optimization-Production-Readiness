# Monitoring Verification

The Monitoring view verifies: user session, conversation/question counts, grounded answers, no-answer responses, retrievable knowledge count, AI service health, security gates, and recent operational events. Sensitive prompt content is not copied into the audit detail; events use action, safe detail, status semantics, and timestamp.
