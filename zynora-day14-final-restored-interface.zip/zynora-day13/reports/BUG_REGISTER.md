# Bug / Defect Register and Regression Report

| ID | Defect found | Fix | Retest |
|---|---|---|---|
| D01 | No login gate in local demo | Added login and help assistant with validation | PASS |
| D02 | Single message list only | Added persistent conversation IDs, new/clear/delete flows | PASS |
| D03 | No monitoring screen | Added production observability view and validation gates | PASS |
| D04 | Injection coverage was narrow | Added system-prompt, other-user, and draft-bypass patterns | PASS |
| D05 | No response timing/confidence | Added telemetry fields to client response | PASS |

**Regression:** Existing chat, evidence rail, source display, knowledge admin, status transitions, and responsive layout remain available. `pnpm run build` passes.
