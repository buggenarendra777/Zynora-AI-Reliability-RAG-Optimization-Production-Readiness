# Accuracy and Groundedness Report

The evaluation model is deterministic and extractive: answers are composed only from retrieved approved content.

Metrics used in the live demo:

- **Accuracy %** = Correct answers / answerable test questions × 100
- **Grounded Answer %** = grounded responses / total responses × 100
- **No-Answer Rate** = safe fallback responses / total responses × 100
- **Retrieval Success %** = questions with an approved relevant chunk / answerable questions × 100

The Monitoring screen calculates successful answers and no-answer responses from the active conversation. Every grounded answer displays source evidence and every unknown/injection answer displays the exact fallback.
