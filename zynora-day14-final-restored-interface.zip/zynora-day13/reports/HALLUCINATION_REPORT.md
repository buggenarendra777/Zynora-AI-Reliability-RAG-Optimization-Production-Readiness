# Hallucination and Knowledge Boundary Report

Unknown policies, prices, commissions, employee information, external company information, and current internet requests are expected to return:

> I couldn't find this information in the approved Zyngram knowledge base.

The browser adapter and backend retrieval service do not call a general-purpose LLM, web search, external websites, or arbitrary URLs. Boundary tests are Q26–Q30 and Q34.
