# Day 14 Release Readiness Report

Generated: 2026-10-09 (local deterministic validation)

## Regression summary

| Metric | Result |
|---|---:|
| Cases | 40 |
| Passed | 40 |
| Failed | 0 |
| Pass rate | 100.0% |
| Grounded answer rate | 55.0% |
| No-answer rate | 45.0% |

## Day 14 controls

- **Approved-source retrieval:** only `APPROVED` and `ACTIVE` documents are candidates; each chunk includes document ID, version, source, approval status, matched terms, score, and chunk ID.
- **Grounding:** unsupported claims are returned as an explicit `unsupported_claims` list; fallback responses contain no sources or chunks.
- **Lifecycle:** draft and archived exclusion plus approved inclusion: [{'case': 'draft excluded', 'status': 'PASS'}, {'case': 'archived excluded', 'status': 'PASS'}, {'case': 'approved active included', 'status': 'PASS'}].
- **Context isolation:** {'cross_user_context_not_shared': 'PASS', 'user_a_grounded_source': 'PASS'}.
- **Prompt injection:** all attack cases passed: True.
- **Performance:** representative API/retrieval timings are in `evidence/day14_summary.json`; no external network or model call is used.

## Evidence

- Full case-by-case matrix: `evidence/day14_regression_matrix.csv`
- Machine-readable summary: `evidence/day14_summary.json`

## Release decision

**CONDITIONAL PASS** — the deterministic approved-content implementation and regression controls pass locally. A production release still requires deployment-specific health, browser-load, and repository verification.
