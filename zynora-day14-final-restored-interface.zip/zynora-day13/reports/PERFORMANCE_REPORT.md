# Production Performance Report

The browser adapter records `responseTimeMs` and confidence for every response and the monitoring screen displays operational counts and health. The seeded local run uses a bounded 260 ms retrieval simulation for a repeatable presentation. Backend performance checks should capture first response, retrieval, API, database, concurrent request, long conversation, and frontend-load timing with browser DevTools or curl. No external AI call is on the critical path.
