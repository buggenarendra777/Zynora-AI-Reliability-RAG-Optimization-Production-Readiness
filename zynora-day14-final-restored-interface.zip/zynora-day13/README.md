

## Day 14 reliability and production-readiness additions

Day 14 adds measurable, deterministic controls without introducing web search, an external LLM, or unapproved retrieval:

- Query normalization and alias handling for improved approved-source ranking.
- Strict `APPROVED`/`ACTIVE` filtering with version, status, matched-term, score, source, and chunk traceability.
- Explicit `unsupported_claims`, confidence, resolved-context, and retrieval-diagnostics fields in API responses.
- Safer ambiguous-question fallback and bounded, user-scoped conversation context.
- Visible monitoring screen with Day 14 validation gates, lifecycle controls, fallback contract, security status, and release-readiness metrics.
- Repeatable Day 14 validation runner covering all 40 regression cases, lifecycle inclusion/exclusion, context isolation, prompt injection, and latency.

Run the Day 14 validation:

```bash
rm -f day14_validation.db
python3 scripts/day14_validation.py
```

The command writes:

- `reports/DAY14_RELEASE_READINESS.md`
- `evidence/day14_regression_matrix.csv`
- `evidence/day14_summary.json`

The generated local result is **40/40 regression cases passed**, with draft/archived exclusion, approved inclusion, cross-user isolation, injection defenses, and representative API/retrieval timings recorded. The release report deliberately remains **CONDITIONAL PASS** until deployment-specific health, browser-load, repository, and production URL evidence is supplied.
