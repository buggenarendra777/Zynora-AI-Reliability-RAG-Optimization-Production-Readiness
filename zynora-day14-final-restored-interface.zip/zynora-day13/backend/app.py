import os
from flask import Flask, jsonify
from flask_cors import CORS
from .config import Config
from .db import db
from .routes.admin import admin_bp
from .routes.auth import auth_bp
from .routes.chat import chat_bp


def create_app(overrides: dict | None = None) -> Flask:
    app = Flask(__name__)
    app.config.from_object(Config)
    if overrides:
        app.config.update(overrides)
    db.init_app(app)
    CORS(app, resources={r'/api/*': {'origins': ['http://localhost:3000', 'http://127.0.0.1:3000'], 'supports_credentials': True}})
    app.register_blueprint(chat_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(auth_bp)
    with app.app_context():
        db.create_all()
    @app.errorhandler(413)
    def too_large(_error):
        return jsonify({'error': 'request payload is too large'}), 413
    @app.errorhandler(500)
    def server_error(_error):
        db.session.rollback()
        return jsonify({'error': 'internal server error'}), 500
    return app


app = create_app()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', '5000')), debug=False)
