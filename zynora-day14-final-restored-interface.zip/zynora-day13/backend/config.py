import json
import os
from urllib.parse import parse_qs, urlencode, urlsplit, urlunsplit


def database_connection(value: str | None) -> tuple[str, dict]:
    if not value:
        return 'sqlite:///zynora-local.db', {}
    # SQLite URLs must be passed through unchanged. urlsplit/urlunsplit can
    # otherwise collapse an absolute SQLite path into an invalid URL.
    if value.startswith('sqlite:'):
        return value, {}
    parts = urlsplit(value.replace('mysql://', 'mysql+pymysql://', 1))
    query = parse_qs(parts.query)
    connect_args: dict = {}
    ssl_value = query.pop('ssl', [None])[0]
    if ssl_value:
        try:
            ssl_config = json.loads(ssl_value)
        except json.JSONDecodeError:
            ssl_config = {}
        if ssl_config.get('rejectUnauthorized', True):
            connect_args.update({'ssl_verify_cert': True, 'ssl_verify_identity': True})
    clean_url = urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query, doseq=True), parts.fragment))
    return clean_url, connect_args


DATABASE_URL, DATABASE_CONNECT_ARGS = database_connection(os.environ.get('DATABASE_URL'))


class Config:
    SQLALCHEMY_DATABASE_URI = DATABASE_URL
    SQLALCHEMY_ENGINE_OPTIONS = {'pool_pre_ping': True, 'connect_args': DATABASE_CONNECT_ARGS}
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    JSON_SORT_KEYS = False
    MAX_CONTENT_LENGTH = 2 * 1024 * 1024
    MANUS_PROJECT_ID = os.environ.get('MANUS_PROJECT_ID')
    MANUS_JWT_SECRET = os.environ.get('MANUS_JWT_SECRET')
    ADMIN_OPEN_IDS = {item.strip() for item in os.environ.get('ADMIN_OPEN_IDS', '').split(',') if item.strip()}
