import json
import re
from pathlib import Path
from typing import Any

SUPPORTED_EXTENSIONS = {'.txt', '.md', '.markdown', '.json'}
MAX_FILE_BYTES = 2 * 1024 * 1024


def clean_text(content: str) -> str:
    return re.sub(r'\n{3,}', '\n\n', re.sub(r'[ \t]+', ' ', content)).strip()


def parse_document(path: str | Path) -> dict[str, Any]:
    file_path = Path(path)
    if file_path.suffix.lower() not in SUPPORTED_EXTENSIONS:
        raise ValueError('Only TXT, Markdown, and JSON files are supported.')
    if file_path.stat().st_size > MAX_FILE_BYTES:
        raise ValueError('Knowledge file exceeds the 2 MB limit.')
    raw = file_path.read_text(encoding='utf-8')
    if file_path.suffix.lower() == '.json':
        data = json.loads(raw)
        if isinstance(data, list):
            if len(data) != 1:
                raise ValueError('JSON ingestion expects one document object or a one-item array.')
            data = data[0]
        if not isinstance(data, dict):
            raise ValueError('JSON ingestion expects an object.')
        required = {'id', 'title', 'category', 'content', 'source', 'version', 'status'}
        missing = required - data.keys()
        if missing:
            raise ValueError(f'Missing required JSON fields: {", ".join(sorted(missing))}')
        return {**data, 'content': clean_text(str(data['content']))}
    headings = re.findall(r'^#{1,6}\s+(.+)$', raw, flags=re.MULTILINE)
    title = headings[0] if headings else file_path.stem.replace('-', ' ').replace('_', ' ').title()
    content = clean_text(re.sub(r'^#{1,6}\s+', '', raw, flags=re.MULTILINE))
    return {
        'id': file_path.stem.upper(),
        'title': title,
        'category': 'Company',
        'content': content,
        'source': f'internal://knowledge/{file_path.name}',
        'version': '1.0',
        'status': 'DRAFT',
    }


def split_chunks(document: dict[str, Any], target_chars: int = 2200, overlap_chars: int = 180) -> list[dict[str, Any]]:
    paragraphs = [part.strip() for part in re.split(r'\n\s*\n', document['content']) if part.strip()]
    chunks: list[dict[str, Any]] = []
    current = ''
    for paragraph in paragraphs:
        candidate = f'{current}\n\n{paragraph}'.strip()
        if current and len(candidate) > target_chars:
            chunks.append({'section': document['title'], 'content': current})
            current = f'{current[-overlap_chars:]}\n\n{paragraph}'.strip()
        else:
            current = candidate
    if current:
        chunks.append({'section': document['title'], 'content': current})
    return [{**chunk, 'chunk_index': index, 'search_text': f"{document['title']} {document['category']} {chunk['section']} {chunk['content']}"} for index, chunk in enumerate(chunks)]
