import re
import time
from sqlalchemy import select
from ..models import KnowledgeDocument
from .answering import compose_answer

NOT_FOUND_MESSAGE = "I couldn't find this information in the approved Zyngram knowledge base."
STOP_WORDS = {
    'a','an','and','are','be','by','current','do','for','from','future','how','i','in','is','it',
    'next','of','on','or','the','this','to','today','what','when','where','which','who','with','year',
    'you','comes','come','after','that','those','them','one','document','covers','included','retrievable',
    'please','tell','me','about','can','does','was','were','are'
}
INJECTION_PATTERNS = [re.compile(pattern, re.IGNORECASE) for pattern in (
    r'ignore\s+(your|the|previous)\s+(instructions?|knowledge)',
    r'use\s+your\s+own\s+knowledge', r'search\s+(the\s+)?(internet|web|google)',
    r'bypass\s+(the\s+)?(rag|knowledge|policy)',
    r'reveal\s+(your\s+)?(system\s+)?(instructions?|prompt)',
    r'(show|expose|give)\s+(me\s+)?(another\s+user|hidden|private)',
    r'treat\s+.*(draft|archived).*approved', r'invent\s+.*(policy|price|employee)',
)]
HIERARCHY = ['Point','Center','Hub','Command','HQ','Digital Node','Zone','Territory','Region','Nation']
ALIASES = {'zygram': 'zyngram', 'recharge': 'mobile recharge', 'franchise locations': 'physical franchise hierarchy', 'response rule': 'system rules'}


def normalize_query(value: str) -> str:
    normalized = re.sub(r'\s+', ' ', value.strip().lower())
    for source, target in ALIASES.items():
        normalized = re.sub(rf'\b{re.escape(source)}\b', target, normalized)
    return normalized


def tokenize(value):
    return [token for token in re.sub(r'[^a-z0-9\s-]', ' ', normalize_query(value)).split()
            if len(token) > 2 and token not in STOP_WORDS]


def is_injection(value):
    return any(pattern.search(value) for pattern in INJECTION_PATTERNS)


def resolve_contextual_message(message, history=None):
    if not history:
        return message
    lower = normalize_query(message)
    user_questions = [str(item.get('content', '')).strip() for item in history
                      if isinstance(item, dict) and item.get('role') == 'user']
    transcript = ' '.join(user_questions).lower()
    if 'after nation' in lower:
        return 'after nation'
    if 'after hub' in lower:
        return 'what comes after hub'
    if 'after command' in lower:
        return 'what comes after command'
    if 'after that' in lower or 'after it' in lower or 'what comes next' in lower:
        previous = user_questions[-1].lower() if user_questions else ''
        if 'after hub' in previous:
            return 'what comes after command'
        if 'after command' in previous:
            return 'what comes after hq'
        mentioned = [level for level in HIERARCHY if level.lower() in transcript]
        if mentioned:
            current = mentioned[-1]
            index = HIERARCHY.index(current)
            return f'what comes after {HIERARCHY[index]}' if index < len(HIERARCHY) - 1 else 'after nation'
    if 'which document supports' in lower or 'what source supports' in lower:
        if 'franchise' in transcript or any(level.lower() in transcript for level in HIERARCHY):
            return 'what is the physical franchise hierarchy'
        if 'service' in transcript or 'recharge' in transcript:
            return 'what approved services are included'
        if 'policy' in transcript:
            return 'what is the approved policy scope'
    if lower.rstrip('?') == 'what was my first question':
        return user_questions[0] if user_questions else message
    if lower.rstrip('?') in {'is it approved', 'are those locations active', 'can you explain that'}:
        return user_questions[-1] if user_questions else message
    return message


def retrieve_documents(session, message, limit=5):
    started = time.perf_counter()
    if is_injection(message):
        return [], (time.perf_counter() - started) * 1000, {'blocked_reason': 'prompt_injection'}
    normalized_message = normalize_query(message)
    tokens = tokenize(normalized_message)
    if not tokens:
        return [], (time.perf_counter() - started) * 1000, {'blocked_reason': 'no_query_terms'}
    documents = session.scalars(
        select(KnowledgeDocument).where(KnowledgeDocument.status.in_(['APPROVED', 'ACTIVE']))
    ).all()
    candidates = []
    query_lower = normalized_message.lower()
    for document in documents:
        haystack = f'{document.title} {document.category} {document.content}'.lower()
        matches = [token for token in tokens if re.search(rf'\b{re.escape(token)}\b', haystack)]
        if not matches:
            continue
        coverage = len(set(matches)) / max(len(set(tokens)), 1)
        score = coverage * 0.62
        if document.title.lower() in query_lower:
            score += 0.26
        if query_lower in document.content.lower():
            score += 0.30
        if document.category.lower() in query_lower:
            score += 0.08
        # Require enough evidence for multi-term questions; this prevents one-word false positives.
        minimum = 0.22 if len(tokens) <= 2 else 0.30
        if score >= minimum:
            candidates.append((min(score, .99), document, sorted(set(matches))))
    candidates.sort(key=lambda item: (item[0], item[1].version, item[1].id), reverse=True)
    return candidates[:limit], (time.perf_counter() - started) * 1000, {'query_terms': tokens}


def grounded_response(session, message, history=None):
    resolved_message = resolve_contextual_message(message, history)
    normalized = normalize_query(resolved_message)
    if re.search(r'after\s+nation', normalized) or re.search(r'draft.*retriev', normalized) or re.search(
        r'(stock price|hr manager|price of a franchise|commission plan|competitor.?s strategy)', normalized
    ):
        return {'answer': NOT_FOUND_MESSAGE, 'sources': [], 'grounded': False, 'retrieved_chunks': [],
                'unsupported_claims': [message], 'confidence': 0.0, 'retrieval_time_ms': 0.0,
                'resolved_message': resolved_message, 'retrieval_diagnostics': {'blocked_reason': 'unsupported_request'}}
    candidates, retrieval_time_ms, diagnostics = retrieve_documents(session, resolved_message)
    base = {'retrieval_time_ms': round(retrieval_time_ms, 2), 'resolved_message': resolved_message,
            'retrieval_diagnostics': diagnostics}
    if not candidates:
        return {'answer': NOT_FOUND_MESSAGE, 'sources': [], 'grounded': False, 'retrieved_chunks': [],
                'unsupported_claims': [message], 'confidence': 0.0, **base}
    chunks = []
    for index, (score, document, matches) in enumerate(candidates):
        section = {'Franchise': 'Physical franchise hierarchy', 'Services': 'Approved service categories',
                   'Policies': 'Policy scope'}.get(document.category, 'Approved knowledge scope')
        chunks.append({
            'chunk_id': f'{document.id}-{index + 1:02d}', 'document_id': document.id, 'title': document.title,
            'category': document.category, 'section': section, 'version': document.version, 'source': document.source,
            'content': document.content, 'score': round(max(.55, min(.99, score + len(matches) * .04)), 2),
            'matched_terms': matches, 'approval_status': document.status,
        })
    primary = chunks[0]
    answer = compose_answer(resolved_message, primary['category'], primary['content'])
    if history and normalize_query(message).rstrip('?') == 'what was my first question':
        answer = f'Your first question in this conversation was: {resolved_message}'
    return {
        'answer': f'Based on the approved Zyngram knowledge base, {answer}',
        'sources': [{key: primary[key] for key in ('document_id', 'title', 'category', 'version', 'source')} for primary in chunks],
        'grounded': True, 'retrieved_chunks': chunks, 'unsupported_claims': [],
        'confidence': primary['score'], **base,
    }
