import re


def compose_answer(message: str, category: str, content: str) -> str:
    """Compose a concise extractive answer from approved content only.

    This is intentionally rule-based: no external model or outside knowledge
    is used. The response is selected from the approved document's facts.
    """
    query = message.lower()
    sentences = [part.strip() for part in re.split(r'(?<=[.!?])\s+', content.strip()) if part.strip()]

    if category == 'Company':
        if 'what is zyngram' in query or 'what is zygram' in query:
            return 'Zyngram is a digital ecosystem platform that combines many platforms and services into one integrated application.'
        if any(term in query for term in ('area', 'scope', 'cover')):
            return 'The approved Zyngram knowledge areas are company overview, vision, mission, ecosystem, and platform structure.'
    if category == 'Services':
        if 'mobile recharge' in query:
            return 'Mobile Recharge is one of the approved Zyngram service categories.'
        if any(term in query for term in ('service', 'included', 'category')):
            return sentences[0] if sentences else content
    if category == 'Franchise':
        return 'The physical franchise hierarchy runs from Point, Center, Hub, Command, HQ and Digital Node through Zone, Territory, Region and Nation.'
    if category == 'Policies' and sentences:
        return sentences[0]
    if category == 'FAQ' and any(term in query for term in ('absent', 'missing', 'not exist', 'not found')):
        return sentences[-1] if sentences else content
    if category == 'System' and sentences:
        return sentences[0]

    query_terms = [term for term in re.sub(r'[^a-z0-9\s]', ' ', query).split() if len(term) > 3]
    relevant = [sentence for sentence in sentences if any(term in sentence.lower() for term in query_terms)]
    return ' '.join(relevant[:2]) if relevant else (sentences[0] if sentences else content)
