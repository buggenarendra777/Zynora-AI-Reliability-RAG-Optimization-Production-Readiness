from __future__ import annotations

from datetime import datetime
from typing import Any

from ..db import db
from ..models import ObservabilityEvent


def record_event(
    *,
    user_id: str | None,
    conversation_id: str | None,
    event_type: str,
    question: str | None = None,
    retrieval: dict[str, Any] | None = None,
    response: dict[str, Any] | None = None,
    sources: list[dict[str, Any]] | None = None,
    response_time_ms: float | None = None,
    error: str | None = None,
    service_status: str = 'HEALTHY',
) -> None:
    safe_question = question[:1000] if question else None
    db.session.add(ObservabilityEvent(
        user_id=user_id,
        conversation_id=conversation_id,
        event_type=event_type,
        question=safe_question,
        retrieval=retrieval,
        response=response,
        sources=sources,
        response_time_ms=response_time_ms,
        error=error,
        service_status=service_status,
        created_at=datetime.utcnow(),
    ))


def summarize_events() -> dict[str, Any]:
    events = db.session.query(ObservabilityEvent).order_by(ObservabilityEvent.created_at.desc()).limit(1000).all()
    responses = [event for event in events if event.event_type == 'RESPONSE']
    failed = [event for event in events if event.event_type == 'FAILED_RETRIEVAL']
    timings = [event.response_time_ms for event in responses if event.response_time_ms is not None]
    return {
        'events': len(events),
        'questions': sum(event.event_type == 'QUESTION' for event in events),
        'retrievals': sum(event.event_type == 'RETRIEVAL' for event in events),
        'responses': len(responses),
        'failed_retrievals': len(failed),
        'errors': sum(event.event_type == 'ERROR' for event in events),
        'avg_response_time_ms': round(sum(timings) / len(timings), 2) if timings else 0,
        'last_service_status': events[0].service_status if events else 'HEALTHY',
        'recent_events': [event.to_dict() for event in events[:20]],
    }
