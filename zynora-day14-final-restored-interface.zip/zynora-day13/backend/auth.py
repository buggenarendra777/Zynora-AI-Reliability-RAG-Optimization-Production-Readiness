from functools import wraps
import jwt
from flask import current_app, g, jsonify, request
from .db import db
from .models import User


def current_user():
    if hasattr(g, 'zynora_user'):
        return g.zynora_user
    token = request.cookies.get('webdev_app_session')
    secret = current_app.config.get('MANUS_JWT_SECRET')
    project_id = current_app.config.get('MANUS_PROJECT_ID')
    if not token or not secret:
        g.zynora_user = None
        return None
    try:
        claims = jwt.decode(token, secret, algorithms=['HS256'], options={'verify_aud': False})
        if project_id and claims.get('appId') not in (None, project_id):
            raise jwt.InvalidTokenError('appId mismatch')
        open_id = claims.get('openId') or claims.get('sub')
        if not open_id:
            raise jwt.InvalidTokenError('missing openId')
    except jwt.PyJWTError:
        g.zynora_user = None
        return None
    user = db.session.scalar(db.select(User).where(User.open_id == open_id))
    if not user:
        user = User(open_id=open_id, email=claims.get('email'), name=claims.get('name'), role='USER')
        db.session.add(user)
        db.session.commit()
    if not user.is_active:
        g.zynora_user = None
        return None
    g.zynora_user = user
    return user


def require_auth(handler):
    @wraps(handler)
    def wrapped(*args, **kwargs):
        if not current_user():
            return jsonify({'error': 'Authentication required'}), 401
        return handler(*args, **kwargs)
    return wrapped


def require_admin(handler):
    @wraps(handler)
    def wrapped(*args, **kwargs):
        user = current_user()
        if not user:
            return jsonify({'error': 'Authentication required'}), 401
        allowlisted = user.open_id in current_app.config.get('ADMIN_OPEN_IDS', set())
        if user.role != 'ADMIN' and not allowlisted:
            return jsonify({'error': 'Admin authorization required'}), 403
        return handler(*args, **kwargs)
    return wrapped
