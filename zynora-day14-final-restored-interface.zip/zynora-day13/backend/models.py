from datetime import datetime
from .db import db

class KnowledgeDocument(db.Model):
    __tablename__ = 'knowledge_documents'
    id = db.Column(db.String(50), primary_key=True)
    title = db.Column(db.String(255), nullable=False)
    category = db.Column(db.String(100), nullable=False)
    content = db.Column(db.Text, nullable=False)
    source = db.Column(db.String(500), nullable=False)
    version = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(20), nullable=False, default='DRAFT')
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

class KnowledgeChunk(db.Model):
    __tablename__ = 'knowledge_chunks'
    id = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    document_id = db.Column(db.String(50), db.ForeignKey('knowledge_documents.id', ondelete='CASCADE'), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    category = db.Column(db.String(100), nullable=False)
    section = db.Column(db.String(255), nullable=False)
    version = db.Column(db.String(50), nullable=False)
    source = db.Column(db.String(500), nullable=False)
    status = db.Column(db.String(20), nullable=False)
    content = db.Column(db.Text, nullable=False)
    chunk_index = db.Column(db.Integer, nullable=False)
    search_text = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    open_id = db.Column(db.String(255), unique=True, nullable=False)
    email = db.Column(db.String(255))
    name = db.Column(db.String(255))
    role = db.Column(db.String(20), nullable=False, default='USER')
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

class AuditLog(db.Model):
    __tablename__ = 'audit_logs'
    id = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    user_id = db.Column(db.BigInteger, db.ForeignKey('users.id', ondelete='SET NULL'))
    action = db.Column(db.String(80), nullable=False)
    entity_type = db.Column(db.String(80), nullable=False)
    entity_id = db.Column(db.String(80))
    details = db.Column(db.JSON)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

class ObservabilityEvent(db.Model):
    __tablename__ = 'observability_events'
    # Integer keeps SQLite local validation compatible while MySQL remains BIGINT in schema.sql.
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.String(255))
    conversation_id = db.Column(db.String(255))
    event_type = db.Column(db.String(40), nullable=False)
    question = db.Column(db.String(1000))
    retrieval = db.Column(db.JSON)
    response = db.Column(db.JSON)
    sources = db.Column(db.JSON)
    response_time_ms = db.Column(db.Float)
    error = db.Column(db.String(500))
    service_status = db.Column(db.String(30), nullable=False, default='HEALTHY')
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def to_dict(self):
        return {
            'id': self.id, 'user_id': self.user_id, 'conversation_id': self.conversation_id,
            'event_type': self.event_type, 'question': self.question, 'retrieval': self.retrieval,
            'response': self.response, 'sources': self.sources, 'response_time_ms': self.response_time_ms,
            'error': self.error, 'service_status': self.service_status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
        }
