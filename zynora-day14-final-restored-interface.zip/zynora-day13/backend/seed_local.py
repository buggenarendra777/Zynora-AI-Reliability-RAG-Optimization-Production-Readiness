"""Create a local SQLite database containing approved Zynora demo records.

Run with:
  DATABASE_URL=sqlite:///zynora-local.db python -m backend.seed_local
"""

from backend.app import create_app
from backend.db import db
from backend.models import KnowledgeDocument


RECORDS = [
    {
        'id': 'KB001',
        'title': 'Zyngram Overview',
        'category': 'Company',
        'content': 'Zyngram is a digital ecosystem platform that combines many platforms and services into one integrated application. The approved Zyngram knowledge scope also covers the company overview, vision, mission, ecosystem, and platform structure.',
        'source': 'internal://approved/company/KB001.md',
        'version': '1.0',
        'status': 'APPROVED',
    },
    {
        'id': 'KB002',
        'title': 'Approved Zyngram Services',
        'category': 'Services',
        'content': 'Approved Zyngram service categories include Mobile Recharge, utility services, e-commerce, logistics, food delivery, jobs, freelancing, and other approved services.',
        'source': 'internal://approved/services/KB002.md',
        'version': '1.0',
        'status': 'ACTIVE',
    },
    {
        'id': 'KB003',
        'title': 'Zyngram Franchise Structure',
        'category': 'Franchise',
        'content': 'The approved physical franchise hierarchy is Point, Center, Hub, Command, HQ and Digital Node, followed by Zone, Territory, Region and Nation.',
        'source': 'internal://approved/franchise/KB003.md',
        'version': '1.0',
        'status': 'APPROVED',
    },
    {
        'id': 'KB004',
        'title': 'Approved Zyngram Policies',
        'category': 'Policies',
        'content': 'The approved policy scope includes the Code of Conduct, Promotional Guidelines, and approved business and user policies.',
        'source': 'internal://approved/policies/KB004.md',
        'version': '1.0',
        'status': 'ACTIVE',
    },
]


app = create_app()
with app.app_context():
    db.drop_all()
    db.create_all()
    db.session.add_all(KnowledgeDocument(**record) for record in RECORDS)
    db.session.commit()
    print(f'Created local database with {len(RECORDS)} approved records.')
