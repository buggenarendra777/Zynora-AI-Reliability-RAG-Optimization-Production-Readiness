import time
from flask import Blueprint, jsonify, request
from ..db import db
from ..services.observability import record_event, summarize_events
from ..services.retrieval import grounded_response

chat_bp = Blueprint('chat', __name__, url_prefix='/api')

@chat_bp.get('/health')
def health():
    return jsonify({'status':'ok','service':'zynora-api','retrieval':'approved-content-only','observability':'enabled'})

@chat_bp.get('/observability/summary')
def observability_summary():
    return jsonify(summarize_events())

@chat_bp.post('/zynora/chat')
def chat():
    started = time.perf_counter()
    payload = request.get_json(silent=True) or {}
    message = payload.get('message')
    history = payload.get('history') or []
    if not isinstance(message, str) or not message.strip(): return jsonify({'error':'message must be a non-empty string'}), 400
    if len(message) > 1000: return jsonify({'error':'message must not exceed 1000 characters'}), 400
    if not isinstance(history, list) or len(history) > 24: return jsonify({'error':'history must be a list of at most 24 messages'}), 400
    user_id = str(payload.get('user_id'))[:255] if payload.get('user_id') is not None else None
    conversation_id = str(payload.get('conversation_id'))[:255] if payload.get('conversation_id') is not None else None
    safe_history = [item for item in history if isinstance(item, dict) and item.get('role') in {'user','assistant'} and isinstance(item.get('content'), str)][-12:]
    try:
        record_event(user_id=user_id, conversation_id=conversation_id, event_type='QUESTION', question=message, response={'history_messages':len(safe_history)})
        response = grounded_response(db.session, message.strip(), safe_history)
        api_time_ms = (time.perf_counter()-started)*1000
        response['api_response_time_ms'] = round(api_time_ms,2)
        retrieval = {
            'retrieved_chunks': len(response['retrieved_chunks']),
            'grounded': response['grounded'],
            'confidence': response.get('confidence', 0),
            'unsupported_claims': response.get('unsupported_claims', []),
            'retrieval_time_ms': response.get('retrieval_time_ms', 0),
            'resolved_message': response.get('resolved_message', message.strip()),
            'diagnostics': response.get('retrieval_diagnostics', {}),
        }
        record_event(user_id=user_id, conversation_id=conversation_id, event_type='RETRIEVAL', question=message, retrieval=retrieval, sources=response.get('sources',[]), response_time_ms=response.get('retrieval_time_ms',0))
        record_event(user_id=user_id, conversation_id=conversation_id, event_type='RESPONSE', question=message, retrieval=retrieval, response={'grounded':response['grounded'],'answer_length':len(response['answer'])}, sources=response.get('sources',[]), response_time_ms=api_time_ms)
        db.session.commit()
        return jsonify(response)
    except Exception as error:
        db.session.rollback()
        record_event(user_id=user_id, conversation_id=conversation_id, event_type='ERROR', question=message, error=str(error)[:500], service_status='DEGRADED')
        db.session.commit()
        return jsonify({'error':'internal server error'}), 500
