from datetime import datetime
from flask import Blueprint, jsonify, request, g
from sqlalchemy import or_
from ..auth import require_admin
from ..db import db
from ..models import AuditLog, KnowledgeChunk, KnowledgeDocument
from ..services.ingestion import split_chunks
from ..services.ingestion import parse_document

admin_bp = Blueprint('admin', __name__, url_prefix='/api/admin')
ALLOWED_STATUSES = {'DRAFT', 'APPROVED', 'ACTIVE', 'ARCHIVED'}


def serialize_document(document: KnowledgeDocument) -> dict:
    return {'id': document.id, 'title': document.title, 'category': document.category, 'content': document.content, 'source': document.source, 'version': document.version, 'status': document.status, 'created_at': document.created_at.isoformat(), 'updated_at': document.updated_at.isoformat()}


def audit(action: str, entity_id: str, detail: str):
    event = AuditLog(user_id=g.zynora_user.id, action=action, entity_type='KNOWLEDGE_DOCUMENT', entity_id=entity_id, details={'detail': detail})
    db.session.add(event)


def reindex(document: KnowledgeDocument):
    KnowledgeChunk.query.filter_by(document_id=document.id).delete()
    for chunk in split_chunks({'id': document.id, 'title': document.title, 'category': document.category, 'content': document.content, 'source': document.source, 'version': document.version, 'status': document.status}):
        db.session.add(KnowledgeChunk(document_id=document.id, title=document.title, category=document.category, section=chunk['section'], version=document.version, source=document.source, status=document.status, content=chunk['content'], chunk_index=chunk['chunk_index'], search_text=chunk['search_text']))


@admin_bp.get('/documents')
@require_admin
def list_documents():
    query = request.args.get('q', '').strip()
    status = request.args.get('status')
    category = request.args.get('category')
    statement = db.select(KnowledgeDocument).order_by(KnowledgeDocument.updated_at.desc())
    if query:
        term = f'%{query}%'
        statement = statement.where(or_(KnowledgeDocument.id.like(term), KnowledgeDocument.title.like(term), KnowledgeDocument.content.like(term)))
    if status in ALLOWED_STATUSES:
        statement = statement.where(KnowledgeDocument.status == status)
    if category:
        statement = statement.where(KnowledgeDocument.category == category)
    return jsonify({'documents': [serialize_document(document) for document in db.session.scalars(statement).all()]})


@admin_bp.post('/ingest')
@require_admin
def ingest_document():
    """Parse one approved-local file and store it as a knowledge document.

    The endpoint deliberately accepts an uploaded file rather than a URL, so
    arbitrary external retrieval cannot enter the RAG pipeline.
    """
    uploaded = request.files.get('file')
    if not uploaded or not uploaded.filename:
        return jsonify({'error': 'multipart field "file" is required'}), 400
    import tempfile
    from pathlib import Path
    suffix = Path(uploaded.filename).suffix.lower()
    if suffix not in {'.txt', '.md', '.markdown', '.json'}:
        return jsonify({'error': 'Only TXT, Markdown, and JSON files are supported.'}), 400
    with tempfile.NamedTemporaryFile(suffix=suffix) as temporary:
        uploaded.save(temporary.name)
        temporary.flush()
        try:
            payload = parse_document(temporary.name)
        except (OSError, UnicodeError, ValueError) as error:
            return jsonify({'error': str(error)}), 400
    if payload.get('source', '').lower().startswith(('http://', 'https://')):
        return jsonify({'error': 'external URLs are not permitted as knowledge sources'}), 400
    if payload.get('status') not in ALLOWED_STATUSES:
        return jsonify({'error': 'invalid knowledge status'}), 400
    if db.session.get(KnowledgeDocument, payload['id']):
        return jsonify({'error': 'document id already exists'}), 409
    document = KnowledgeDocument(**{key: str(payload[key]).strip() for key in ('id', 'title', 'category', 'content', 'source', 'version', 'status')})
    db.session.add(document)
    db.session.flush()
    reindex(document)
    audit('INGEST_DOCUMENT', document.id, f'Ingested {document.title} from uploaded file')
    db.session.commit()
    return jsonify({'document': serialize_document(document)}), 201


@admin_bp.post('/documents')
@require_admin
def create_document():
    payload = request.get_json(silent=True) or {}
    required = ['id', 'title', 'category', 'content', 'source', 'version', 'status']
    if any(not isinstance(payload.get(key), str) or not payload[key].strip() for key in required):
        return jsonify({'error': 'id, title, category, content, source, version, and status are required'}), 400
    if payload['status'] not in ALLOWED_STATUSES:
        return jsonify({'error': 'invalid knowledge status'}), 400
    if payload['source'].lower().startswith(('http://', 'https://')):
        return jsonify({'error': 'external URLs are not permitted as knowledge sources'}), 400
    if db.session.get(KnowledgeDocument, payload['id']):
        return jsonify({'error': 'document id already exists'}), 409
    document = KnowledgeDocument(**{key: payload[key].strip() for key in required})
    db.session.add(document)
    db.session.flush()
    reindex(document)
    audit('CREATE_DOCUMENT', document.id, f'Created {document.title}')
    db.session.commit()
    return jsonify({'document': serialize_document(document)}), 201


@admin_bp.put('/documents/<document_id>')
@require_admin
def update_document(document_id: str):
    document = db.session.get(KnowledgeDocument, document_id)
    if not document:
        return jsonify({'error': 'document not found'}), 404
    payload = request.get_json(silent=True) or {}
    for key in ('title', 'category', 'content', 'source', 'version'):
        if key in payload and isinstance(payload[key], str) and payload[key].strip():
            if key == 'source' and payload[key].lower().startswith(('http://', 'https://')):
                return jsonify({'error': 'external URLs are not permitted as knowledge sources'}), 400
            setattr(document, key, payload[key].strip())
    document.updated_at = datetime.utcnow()
    reindex(document)
    audit('EDIT_DOCUMENT', document.id, f'Updated {document.title}')
    db.session.commit()
    return jsonify({'document': serialize_document(document)})


@admin_bp.patch('/documents/<document_id>/status')
@require_admin
def update_status(document_id: str):
    document = db.session.get(KnowledgeDocument, document_id)
    if not document:
        return jsonify({'error': 'document not found'}), 404
    next_status = (request.get_json(silent=True) or {}).get('status')
    allowed = {('DRAFT', 'APPROVED'), ('APPROVED', 'ACTIVE'), ('ACTIVE', 'ARCHIVED')}
    if (document.status, next_status) not in allowed:
        return jsonify({'error': f'invalid status transition {document.status} -> {next_status}'}), 400
    document.status = next_status
    document.updated_at = datetime.utcnow()
    KnowledgeChunk.query.filter_by(document_id=document.id).update({'status': next_status})
    audit('STATUS_CHANGE', document.id, f'{document.id} moved to {next_status}')
    db.session.commit()
    return jsonify({'document': serialize_document(document)})


@admin_bp.post('/documents/<document_id>/reindex')
@require_admin
def reindex_document(document_id: str):
    document = db.session.get(KnowledgeDocument, document_id)
    if not document:
        return jsonify({'error': 'document not found'}), 404
    reindex(document)
    audit('REINDEX_DOCUMENT', document.id, f'Reindexed {document.id}')
    db.session.commit()
    return jsonify({'status': 'reindexed', 'document_id': document.id})


@admin_bp.get('/audit-logs')
@require_admin
def audit_logs():
    events = db.session.scalars(db.select(AuditLog).order_by(AuditLog.created_at.desc()).limit(100)).all()
    return jsonify({'audit_logs': [{'id': event.id, 'action': event.action, 'entity_type': event.entity_type, 'entity_id': event.entity_id, 'details': event.details, 'created_at': event.created_at.isoformat()} for event in events]})
