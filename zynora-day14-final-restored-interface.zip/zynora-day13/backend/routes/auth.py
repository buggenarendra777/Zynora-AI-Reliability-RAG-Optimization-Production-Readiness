from flask import Blueprint, jsonify, make_response
from ..auth import current_user

auth_bp = Blueprint('auth', __name__, url_prefix='/api/auth')


@auth_bp.get('/me')
def me():
    user = current_user()
    if not user:
        return jsonify({'authenticated': False}), 401
    return jsonify({'authenticated': True, 'user': {'id': user.id, 'open_id': user.open_id, 'email': user.email, 'name': user.name, 'role': user.role}})


@auth_bp.post('/logout')
def logout():
    response = make_response(jsonify({'status': 'logged_out'}))
    response.delete_cookie('webdev_app_session', secure=True, samesite='None')
    return response
