import json
import os
import re
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlsplit, urlunsplit
from sqlalchemy import create_engine, text


def connection_config(value: str) -> tuple[str, dict]:
    parts = urlsplit(value.replace('mysql://', 'mysql+pymysql://', 1))
    query = parse_qs(parts.query)
    connect_args: dict = {}
    ssl_value = query.pop('ssl', [None])[0]
    if ssl_value:
        try:
            ssl_config = json.loads(ssl_value)
        except json.JSONDecodeError:
            ssl_config = {}
        if ssl_config.get('rejectUnauthorized', True):
            connect_args.update({'ssl_verify_cert': True, 'ssl_verify_identity': True})
    clean_url = urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query, doseq=True), parts.fragment))
    return clean_url, connect_args


def run_file(connection, path: Path) -> None:
    statements = [statement.strip() for statement in path.read_text(encoding='utf-8').split(';') if statement.strip()]
    for statement in statements:
        connection.execute(text(statement))


def clean(value: str) -> str:
    return re.sub(r'\n{3,}', '\n\n', re.sub(r'[ \t]+', ' ', value)).strip()


def seed_chunks(connection) -> None:
    documents = connection.execute(text('SELECT id, title, category, content, source, version, status FROM knowledge_documents')).mappings().all()
    for document in documents:
        connection.execute(text('DELETE FROM knowledge_chunks WHERE document_id = :document_id'), {'document_id': document['id']})
        paragraphs = [part.strip() for part in re.split(r'\n\s*\n', clean(document['content'])) if part.strip()]
        content = '\n\n'.join(paragraphs)
        section = {'Franchise': 'Physical franchise hierarchy', 'Services': 'Approved service categories', 'Policies': 'Policy scope'}.get(document['category'], 'Approved knowledge scope')
        connection.execute(text('''INSERT INTO knowledge_chunks (document_id, title, category, section, version, source, status, content, chunk_index, search_text)
            VALUES (:document_id, :title, :category, :section, :version, :source, :status, :content, 0, :search_text)'''), {
                'document_id': document['id'], 'title': document['title'], 'category': document['category'], 'section': section,
                'version': document['version'], 'source': document['source'], 'status': document['status'], 'content': content,
                'search_text': f"{document['title']} {document['category']} {section} {content}",
            })


if __name__ == '__main__':
    database_url = os.environ.get('DATABASE_URL')
    if not database_url:
        raise SystemExit('DATABASE_URL is required for managed MySQL initialization.')
    clean_url, connect_args = connection_config(database_url)
    engine = create_engine(clean_url, connect_args=connect_args, pool_pre_ping=True)
    root = Path(__file__).resolve().parent
    with engine.begin() as connection:
        run_file(connection, root / 'schema.sql')
        run_file(connection, root / 'seed.sql')
        seed_chunks(connection)
    print('Zynora schema, seed records, and knowledge chunks applied successfully.')
