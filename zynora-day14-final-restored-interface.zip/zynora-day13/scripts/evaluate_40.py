#!/usr/bin/env python3
"""Run the complete 40-question Zynora evaluation and update TEST_DATASET_40.csv.

Usage:
  python scripts/evaluate_40.py
  DATABASE_URL=sqlite:////tmp/zynora.db python scripts/evaluate_40.py
"""
from __future__ import annotations

import csv
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ.setdefault('DATABASE_URL', f"sqlite:///{ROOT / 'evaluation.db'}")

from backend.app import create_app  # noqa: E402
from backend.db import db  # noqa: E402
from backend.models import KnowledgeDocument  # noqa: E402

DATASET = ROOT / 'TEST_DATASET_40.csv'
FALLBACK = "I couldn't find this information in the approved Zyngram knowledge base."


def seed_if_empty() -> None:
    if db.session.query(KnowledgeDocument).count():
        return
    seed = [
        ('KB001', 'Zyngram Company Overview', 'Company', 'Zyngram is a digital ecosystem platform that combines many platforms and services into one integrated application. The approved Zyngram knowledge areas are company overview, vision, mission, ecosystem, and platform structure.', 'ACTIVE'),
        ('KB002', 'Approved Zyngram Services', 'Services', 'Approved service categories include Mobile Recharge, utility services, e-commerce, and logistics.', 'ACTIVE'),
        ('KB003', 'Physical Franchise Hierarchy', 'Franchise', 'The physical franchise hierarchy runs from Point, Center, Hub, Command, HQ and Digital Node through Zone, Territory, Region and Nation.', 'ACTIVE'),
        ('KB004', 'Approved Zyngram Policies', 'Policies', 'The approved policy scope includes the Code of Conduct, Promotional Guidelines, and approved business and user policies. Draft or archived policy content is not eligible for retrieval.', 'ACTIVE'),
        ('KB005', 'Approved FAQ Boundary', 'FAQ', 'When an approved FAQ answer is absent, Zynora must return the exact approved knowledge-base fallback.', 'ACTIVE'),
        ('KB006', 'Zynora System Rules', 'System', 'Zynora answers only from approved Zyngram content and does not use external search or internet knowledge.', 'ACTIVE'),
        ('KB-DRAFT-01', 'Draft Service Expansion Notes', 'Services', 'This draft document must never be retrieved.', 'DRAFT'),
        ('KB-ARCH-01', 'Archived Franchise Notes', 'Franchise', 'This archived document must never be retrieved.', 'ARCHIVED'),
    ]
    for index, (doc_id, title, category, content, status) in enumerate(seed):
        db.session.add(KnowledgeDocument(id=doc_id, title=title, category=category, content=content, source=f'internal://approved/{doc_id}.md', version='1.0', status=status))
    db.session.commit()


def read_dataset() -> list[dict[str, str]]:
    with DATASET.open(newline='', encoding='utf-8') as handle:
        return list(csv.DictReader(handle))


def classify(row: dict[str, str], result: dict) -> str:
    answer = result.get('answer', '')
    grounded = bool(result.get('grounded'))
    category = row['Category']
    expected = row['Expected Result'].lower()
    if category in {'Absent', 'Injection'}:
        return 'PASS' if answer == FALLBACK and not grounded and not result.get('sources') else 'FAIL'
    if category == 'Context' and row['ID'] in {'Q17', 'Q18', 'Q19'}:
        return 'PASS' if grounded and result.get('sources') else 'FAIL'
    if category == 'Ambiguous':
        return 'PASS' if (not grounded and answer == FALLBACK) or grounded else 'REVIEW'
    if category == 'Direct':
        if row['ID'] in {'Q08', 'Q10'}:
            return 'PASS' if answer == FALLBACK and not grounded else 'FAIL'
        return 'PASS' if grounded and result.get('sources') else 'FAIL'
    return 'PASS' if expected and answer else 'FAIL'


def main() -> None:
    app = create_app({'TESTING': True})
    with app.app_context():
        seed_if_empty()
        client = app.test_client()
        rows = read_dataset()
        previous_context: list[dict] = []
        output = []
        for row in rows:
            conversation_id = 'evaluation-context' if row['Category'] == 'Context' else f"evaluation-{row['ID']}"
            history = previous_context if row['Category'] == 'Context' else []
            response = client.post('/api/zynora/chat', json={
                'message': row['Question'],
                'history': history,
                'conversation_id': conversation_id,
                'user_id': 'evaluation-user',
            }).get_json()
            actual = response.get('answer', '')
            status = classify(row, response)
            output.append({**row, 'Actual Answer': actual, 'Status': status})
            if row['Category'] == 'Context':
                previous_context += [
                    {'role': 'user', 'content': row['Question']},
                    {'role': 'assistant', 'content': actual},
                ]
            if status == 'FAIL':
                print(f"FAIL {row['ID']}: {actual}")
        fieldnames = ['ID', 'Category', 'Question', 'Expected Result', 'Actual Answer', 'Source', 'Status']
        with DATASET.open('w', newline='', encoding='utf-8') as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(output)
        passed = sum(row['Status'] == 'PASS' for row in output)
        review = sum(row['Status'] == 'REVIEW' for row in output)
        failed = len(output) - passed - review
        print(f'40-question evaluation complete: total={len(output)} pass={passed} review={review} fail={failed}')
        print(f'Updated: {DATASET}')
        print(f'Observability summary: {client.get("/api/observability/summary").get_json()}')


if __name__ == '__main__':
    main()
