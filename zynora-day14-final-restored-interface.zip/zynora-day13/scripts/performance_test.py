#!/usr/bin/env python3
"""Measure Zynora API response performance locally.

Usage: python scripts/performance_test.py
"""
from __future__ import annotations

import concurrent.futures
import os
import statistics
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ.setdefault('DATABASE_URL', f"sqlite:///{ROOT / 'performance.db'}")

from backend.app import create_app  # noqa: E402
from backend.db import db  # noqa: E402
from backend.models import KnowledgeDocument  # noqa: E402


def setup(app):
    with app.app_context():
        if not db.session.query(KnowledgeDocument).count():
            db.session.add(KnowledgeDocument(id='PERF-01', title='Performance Knowledge', category='Company', content='Zyngram is a digital ecosystem platform with approved services and a physical franchise hierarchy.', source='internal://approved/perf.md', version='1.0', status='ACTIVE'))
            db.session.commit()


def request_once(app, index=0):
    started = time.perf_counter()
    response = app.test_client().post('/api/zynora/chat', json={'message': 'What is Zyngram?', 'conversation_id': f'perf-{index}', 'user_id': 'performance-user'})
    return (time.perf_counter() - started) * 1000, response.status_code


def main():
    app = create_app({'TESTING': True})
    setup(app)
    sequential = [request_once(app, i)[0] for i in range(10)]
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
        concurrent_results = list(pool.map(lambda i: request_once(app, i)[0], range(20)))
    history = [{'role': 'user', 'content': f'Previous question {i}'} for i in range(100)]
    started = time.perf_counter()
    app.test_client().post('/api/zynora/chat', json={'message': 'What is Zyngram?', 'history': history, 'conversation_id': 'long-context', 'user_id': 'performance-user'})
    long_context_ms = (time.perf_counter() - started) * 1000
    print('Zynora performance validation')
    print(f'sequential_p50_ms={statistics.median(sequential):.2f}')
    print(f'sequential_p95_ms={sorted(sequential)[max(0, int(len(sequential) * .95) - 1)]:.2f}')
    print(f'concurrent_20_p50_ms={statistics.median(concurrent_results):.2f}')
    print(f'concurrent_20_max_ms={max(concurrent_results):.2f}')
    print(f'long_context_100_messages_ms={long_context_ms:.2f}')
    print('database_query_time_ms=recorded in API observability telemetry')
    print('frontend_load=run Lighthouse or browser DevTools against the Vite URL')


if __name__ == '__main__':
    main()
