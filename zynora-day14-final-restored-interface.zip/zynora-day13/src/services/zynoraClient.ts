import type { ZynoraClient } from '../types/zynora'

export const NOT_FOUND_MESSAGE = "I couldn't find this information in the approved Zyngram knowledge base."

export function createZynoraClient(client: ZynoraClient): ZynoraClient {
  return client
}
