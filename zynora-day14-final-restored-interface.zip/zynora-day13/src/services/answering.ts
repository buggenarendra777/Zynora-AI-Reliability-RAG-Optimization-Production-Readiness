import type { KnowledgeCategory } from '../types/zynora'

export function composeApprovedAnswer(message: string, category: KnowledgeCategory, content: string): string {
  const query = message.toLowerCase()
  const sentences = content.split(/(?<=[.!?])\s+/).map((sentence) => sentence.trim()).filter(Boolean)

  if (category === 'Company') {
    if (query.includes('what is zyngram') || query.includes('what is zygram')) return 'Zyngram is a digital ecosystem platform that combines many platforms and services into one integrated application.'
    if (['area', 'scope', 'cover'].some((term) => query.includes(term))) return 'The approved Zyngram knowledge areas are company overview, vision, mission, ecosystem, and platform structure.'
  }
  if (category === 'Services') {
    if (query.includes('mobile recharge')) return 'Mobile Recharge is one of the approved Zyngram service categories.'
    if (['service', 'included', 'category'].some((term) => query.includes(term))) return sentences[0] ?? content
  }
  if (category === 'Franchise') return 'The physical franchise hierarchy runs from Point, Center, Hub, Command, HQ and Digital Node through Zone, Territory, Region and Nation.'
  if (category === 'Policies') return sentences[0] ?? content
  if (category === 'FAQ' && ['absent', 'missing', 'not exist', 'not found'].some((term) => query.includes(term))) return sentences.at(-1) ?? content
  if (category === 'System') return sentences[0] ?? content

  const queryTerms = query.replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter((term) => term.length > 3)
  const relevant = sentences.filter((sentence) => queryTerms.some((term) => sentence.toLowerCase().includes(term)))
  return relevant.slice(0, 2).join(' ') || sentences[0] || content
}
