import type { ChatMessage, ChatResponse, ZynoraClient } from '../types/zynora'

export function createHttpZynoraClient(baseUrl = ''): ZynoraClient {
  return {
    async sendMessage(message: string, history?: ChatMessage[], metadata?: { userId?: string; conversationId?: string }): Promise<ChatResponse> {
      const response = await fetch(`${baseUrl}/api/zynora/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message, history: history?.slice(-12), user_id: metadata?.userId, conversation_id: metadata?.conversationId }),
      })
      if (!response.ok) {
        throw new Error('Zynora API request failed')
      }
      const payload = await response.json() as Record<string, unknown>
      return {
        answer: String(payload.answer ?? ''),
        sources: ((payload.sources ?? []) as Array<Record<string, unknown>>).map(source => ({
          documentId: String(source.document_id ?? ''), title: String(source.title ?? ''), category: source.category as ChatResponse['sources'][number]['category'],
          version: String(source.version ?? ''), source: String(source.source ?? ''),
        })),
        grounded: Boolean(payload.grounded),
        retrievedChunks: ((payload.retrieved_chunks ?? []) as Array<Record<string, unknown>>).map(chunk => ({
          chunkId: String(chunk.chunk_id ?? ''), documentId: String(chunk.document_id ?? ''), title: String(chunk.title ?? ''),
          category: chunk.category as ChatResponse['retrievedChunks'][number]['category'], section: String(chunk.section ?? ''),
          version: String(chunk.version ?? ''), source: String(chunk.source ?? ''), content: String(chunk.content ?? ''),
          score: Number(chunk.score ?? 0), matchedTerms: (chunk.matched_terms ?? []) as string[], approvalStatus: chunk.approval_status as ChatResponse['retrievedChunks'][number]['approvalStatus'],
        })),
        responseTimeMs: Number(payload.api_response_time_ms ?? 0), confidence: Number(payload.confidence ?? 0),
        unsupportedClaims: (payload.unsupported_claims ?? []) as string[], retrievalDiagnostics: payload.retrieval_diagnostics as Record<string, unknown>,
      }
    },
  }
}
