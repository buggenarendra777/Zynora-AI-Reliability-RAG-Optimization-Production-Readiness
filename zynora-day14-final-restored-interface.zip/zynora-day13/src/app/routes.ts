export const appRoutes = [
  { path: '/', title: 'Zynora Chat' },
  { path: '/admin', title: 'Zynora Knowledge Admin' },
] as const
