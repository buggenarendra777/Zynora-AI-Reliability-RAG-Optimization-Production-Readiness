import { useEffect, useState } from 'react'
import { initialKnowledgeDocuments } from '../data/mockKnowledge'
import { initialMessages } from '../data/mockConversations'
import { createHttpZynoraClient } from '../services/httpZynoraClient'
import { createMockZynoraClient } from '../services/mockZynoraClient'
import type { AuditEvent, ChatMessage, Conversation, KnowledgeDocument, ZynoraUser } from '../types/zynora'
import { AdminWorkspace } from '../components/admin/AdminWorkspace'
import { ChatWorkspace } from '../components/chat/ChatWorkspace'
import { EvidenceRail } from '../components/evidence/EvidenceRail'
import { AppShell } from '../components/shell/AppShell'
import { LoginScreen } from '../components/auth/LoginScreen'
import { MonitoringWorkspace } from '../components/monitoring/MonitoringWorkspace'
import type { AppView } from '../components/shell/Sidebar'
const apiBaseUrl = import.meta.env.VITE_API_BASE_URL?.trim() ?? ''
const load = <T,>(key: string, fallback: T): T => { try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) as T : fallback } catch { return fallback } }
const now = () => new Date().toISOString()
export default function App() {
  const [user, setUser] = useState<ZynoraUser | null>(() => load('zynora-user', null))
  const [view, setView] = useState<AppView>(() => window.location.pathname === '/admin' ? 'admin' : window.location.pathname === '/monitoring' ? 'monitoring' : 'chat')
  const [documents, setDocuments] = useState<KnowledgeDocument[]>(() => load('zynora-documents', initialKnowledgeDocuments))
  const [conversations, setConversations] = useState<Conversation[]>(() => load('zynora-conversations', [{ id: `conv-${Date.now()}`, title: 'Current conversation', messages: load('zynora-messages', initialMessages), createdAt: now(), updatedAt: now() }]))
  const [activeId, setActiveId] = useState(''); const [audits, setAudits] = useState<AuditEvent[]>(() => load('zynora-audits', [])); const [input, setInput] = useState(''); const [loading, setLoading] = useState(false); const [error, setError] = useState<string | null>(null); const [selectedMessageId, setSelectedMessageId] = useState<string | null>(null); const [evidenceOpen, setEvidenceOpen] = useState(false)
  useEffect(() => { if (!activeId && conversations[0]) setActiveId(conversations[0].id) }, [activeId, conversations])
  useEffect(() => { localStorage.setItem('zynora-user', JSON.stringify(user)); localStorage.setItem('zynora-documents', JSON.stringify(documents)); localStorage.setItem('zynora-conversations', JSON.stringify(conversations)); localStorage.setItem('zynora-audits', JSON.stringify(audits)) }, [user, documents, conversations, audits])
  useEffect(() => { const onPop = () => setView(window.location.pathname === '/admin' ? 'admin' : window.location.pathname === '/monitoring' ? 'monitoring' : 'chat'); window.addEventListener('popstate', onPop); return () => window.removeEventListener('popstate', onPop) }, [])
  const active = conversations.find(c => c.id === activeId) ?? conversations[0]; const messages = active?.messages ?? []
  const record = (action: string, detail: string) => setAudits(current => [{ id: `audit-${Date.now()}`, action, detail, createdAt: now() }, ...current])
  const navigate = (next: AppView) => { window.history.pushState({}, '', next === 'chat' ? '/' : `/${next}`); setView(next); if (next === 'chat') setEvidenceOpen(false) }
  const updateActive = (next: ChatMessage[], title?: string) => setConversations(current => current.map(c => c.id === active?.id ? { ...c, messages: next, title: title ?? c.title, updatedAt: now() } : c))
  const newConversation = () => { const c: Conversation = { id: `conv-${Date.now()}`, title: 'New conversation', messages: [], createdAt: now(), updatedAt: now() }; setConversations(current => [c, ...current]); setActiveId(c.id); setSelectedMessageId(null); setInput(''); record('CONVERSATION_CREATED', 'Created a new conversation') }
  const sendMessage = async (messageText = input) => { const text = messageText.trim(); if (!text || loading || !active) return; const userMessage: ChatMessage = { id: `user-${Date.now()}`, role: 'user', content: text, createdAt: now() }; const history = [...messages, userMessage]; updateActive(history, active.title === 'New conversation' ? text.slice(0, 34) : undefined); setInput(''); setError(null); setLoading(true); record('USER_QUESTION', `Question received (${text.length} characters)`); try { const client = apiBaseUrl ? createHttpZynoraClient(apiBaseUrl) : createMockZynoraClient(documents); const response = await client.sendMessage(text, messages, { userId: user?.email, conversationId: active.id }); const assistant: ChatMessage = { id: `assistant-${Date.now()}`, role: 'assistant', content: response.answer, createdAt: now(), grounded: response.grounded, sources: response.sources, retrievedChunks: response.retrievedChunks }; updateActive([...history, assistant]); setSelectedMessageId(assistant.id); setEvidenceOpen(true); record(response.grounded ? 'AI_RESPONSE_GROUNDED' : 'AI_RESPONSE_NO_ANSWER', `${response.grounded ? 'Grounded response' : 'Safe fallback'} · ${response.responseTimeMs ?? 0} ms`) } catch { setError('Zynora could not complete this retrieval. Please try again.'); record('API_ERROR', 'Chat request failed') } finally { setLoading(false) } }
  const clearChat = () => { updateActive([],'New conversation'); setSelectedMessageId(null); setInput(''); setError(null); setEvidenceOpen(false) }
  const deleteActive = () => { if (conversations.length <= 1) return clearChat(); const rest = conversations.filter(c => c.id !== activeId); setConversations(rest); setActiveId(rest[0].id); record('CONVERSATION_DELETED', 'Deleted the active conversation') }
  const signOut = () => setUser(null)
  if (!user) return <LoginScreen onLogin={(name, email) => { setUser({ name, email, role: 'USER' }); record('LOGIN_SUCCESS', `Signed in as ${email}`) }} />
  const chat = <div className="chat-layout"><ChatWorkspace messages={messages} input={input} onInputChange={setInput} onSend={() => void sendMessage()} onClear={clearChat} loading={loading} error={error} selectedMessageId={selectedMessageId} onSelectMessage={message => { setSelectedMessageId(message.id); setEvidenceOpen(true) }} onCopy={content => void navigator.clipboard?.writeText(content)} onPrompt={prompt => void sendMessage(prompt)} /><EvidenceRail message={messages.find(message => message.id === selectedMessageId) ?? null} mobileOpen={evidenceOpen} onToggleMobile={() => setEvidenceOpen(open => !open)} /></div>
  return <AppShell view={view} user={user} onSignOut={signOut} onNavigate={navigate} onClear={clearChat} onNewConversation={newConversation} onDeleteConversation={deleteActive} evidenceOpen={evidenceOpen} onToggleEvidence={() => setEvidenceOpen(open => !open)}>{view === 'chat' ? chat : view === 'admin' ? <AdminWorkspace documents={documents} onDocumentsChange={setDocuments} audits={audits} onAudit={event => setAudits(current => [event, ...current])} /> : <MonitoringWorkspace messages={messages} documents={documents} audits={audits} />}</AppShell>
}
