import type { ChatMessage } from '../types/zynora'

export const initialMessages: ChatMessage[] = [
  {
    id: 'welcome-assistant',
    role: 'assistant',
    content: 'Ask the approved Zyngram knowledge base. I will answer only from content that has been deliberately approved for retrieval.',
    createdAt: '2026-10-05T08:01:00.000Z',
    grounded: true,
    sources: [],
    retrievedChunks: [],
  },
]
