export type KnowledgeStatus = 'DRAFT' | 'APPROVED' | 'ACTIVE' | 'ARCHIVED'
export type KnowledgeCategory = 'Company' | 'Services' | 'Franchise' | 'Policies' | 'FAQ' | 'System'
export type MessageRole = 'user' | 'assistant'
export interface ZynoraUser { name: string; email: string; role: 'USER' | 'ADMIN' }
export interface Conversation { id: string; title: string; messages: ChatMessage[]; createdAt: string; updatedAt: string }
export interface KnowledgeDocument { id: string; title: string; category: KnowledgeCategory; content: string; source: string; version: string; status: KnowledgeStatus; updatedAt: string }
export interface SourceReference { documentId: string; title: string; category: KnowledgeCategory; version: string; source: string }
export interface RetrievedChunk { chunkId: string; documentId: string; title: string; category: KnowledgeCategory; section: string; version: string; source: string; content: string; score: number; matchedTerms?: string[]; approvalStatus?: KnowledgeStatus }
export interface ChatResponse { answer: string; sources: SourceReference[]; grounded: boolean; retrievedChunks: RetrievedChunk[]; responseTimeMs?: number; confidence?: number; unsupportedClaims?: string[]; retrievalDiagnostics?: Record<string, unknown> }
export interface ChatMessage { id: string; role: MessageRole; content: string; createdAt: string; grounded?: boolean; sources?: SourceReference[]; retrievedChunks?: RetrievedChunk[]; error?: boolean }
export interface ZynoraClient { sendMessage(message: string, history?: ChatMessage[], metadata?: { userId?: string; conversationId?: string }): Promise<ChatResponse> }
export interface AuditEvent { id: string; action: string; documentId?: string; detail: string; createdAt: string }
