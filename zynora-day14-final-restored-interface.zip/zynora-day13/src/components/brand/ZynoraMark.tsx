interface ZynoraMarkProps {
  compact?: boolean
}

export function ZynoraMark({ compact = false }: ZynoraMarkProps) {
  return (
    <div className={`zynora-mark ${compact ? 'zynora-mark-compact' : ''}`} aria-label="Zynora">
      <img className="zyngram-logo" src="/zyngram-logo.jpeg" alt="Zyngram logo" />
      {!compact && (
        <span className="zynora-wordmark">
          <strong>ZYNORA</strong>
          <small>ZYNG<span>RAM</span> INTELLIGENCE</small>
        </span>
      )}
    </div>
  )
}
