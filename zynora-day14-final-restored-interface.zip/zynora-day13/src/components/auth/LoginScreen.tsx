import { useState } from 'react'
import { ZynoraMark } from '../brand/ZynoraMark'

interface LoginScreenProps { onLogin: (name: string, email: string) => void }
export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [email, setEmail] = useState('demo@zyngram.com')
  const [password, setPassword] = useState('ZynoraDemo123!')
  const [mode, setMode] = useState<'login' | 'help'>('login')
  const [message, setMessage] = useState('')
  const submit = (event: React.FormEvent) => {
    event.preventDefault()
    if (mode === 'help') { setMessage('Help assistant: use the demo account demo@zyngram.com, or contact your Zyngram administrator for a production reset.'); return }
    if (!email.includes('@') || password.length < 6) { setMessage('Enter a valid email and a password with at least 6 characters.'); return }
    onLogin(email.split('@')[0].replace(/[._-]/g, ' '), email)
  }
  return <main className="auth-page"><section className="auth-card"><div className="auth-brand"><ZynoraMark /></div><span className="eyebrow">Secure workspace</span><h1>{mode === 'login' ? 'Welcome back to Zynora.' : 'Need a hand signing in?'}</h1><p>{mode === 'login' ? 'Sign in to the approved Zyngram knowledge workspace.' : 'The help assistant can guide you to the demo reset path without exposing passwords.'}</p><form onSubmit={submit} className="auth-form">{mode === 'login' && <label>Email<input type="email" value={email} onChange={event => setEmail(event.target.value)} autoComplete="email" required /></label>}<label>{mode === 'login' ? 'Password' : 'Email address'}<input type={mode === 'login' ? 'password' : 'email'} value={mode === 'login' ? password : email} onChange={event => mode === 'login' ? setPassword(event.target.value) : setEmail(event.target.value)} required /></label>{message && <div className="auth-message">{message}</div>}<button className="button button-primary button-lg auth-submit" type="submit">{mode === 'login' ? 'Sign in to Zynora' : 'Get help'}</button></form><div className="auth-links"><button onClick={() => { setMode(mode === 'login' ? 'help' : 'login'); setMessage('') }}>{mode === 'login' ? 'Forgot password? Ask the help assistant' : 'Back to sign in'}</button></div><div className="auth-demo"><strong>Presentation demo</strong><span>demo@zyngram.com · any password with 6+ characters</span></div></section></main>
}
