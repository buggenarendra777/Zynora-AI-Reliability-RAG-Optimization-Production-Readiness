import type { ReactNode } from 'react'
import type { ZynoraUser } from '../../types/zynora'
import { Sidebar, type AppView } from './Sidebar'
import { Topbar } from './Topbar'
interface AppShellProps { view: AppView; user: ZynoraUser; onSignOut: () => void; onNavigate: (view: AppView) => void; onClear: () => void; onNewConversation: () => void; onDeleteConversation: () => void; evidenceOpen: boolean; onToggleEvidence: () => void; children: ReactNode }
export function AppShell(props: AppShellProps) { return <div className="app-shell"><Sidebar view={props.view} user={props.user} onNavigate={props.onNavigate} onSignOut={props.onSignOut} /><div className="app-body"><Topbar view={props.view} onClear={props.onClear} onNewConversation={props.onNewConversation} onDeleteConversation={props.onDeleteConversation} evidenceOpen={props.evidenceOpen} onToggleEvidence={props.onToggleEvidence} />{props.children}</div></div> }
