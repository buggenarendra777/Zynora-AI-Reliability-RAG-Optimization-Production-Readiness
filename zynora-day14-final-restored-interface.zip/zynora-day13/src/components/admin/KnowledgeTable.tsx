import type { KnowledgeCategory, KnowledgeDocument, KnowledgeStatus } from '../../types/zynora'
import { Button } from '../common/Button'
import { StatusBadge } from './StatusBadge'

interface KnowledgeTableProps {
  documents: KnowledgeDocument[]
  query: string
  onQueryChange: (value: string) => void
  status: 'ALL' | KnowledgeStatus
  onStatusChange: (value: 'ALL' | KnowledgeStatus) => void
  category: 'ALL' | KnowledgeCategory
  onCategoryChange: (value: 'ALL' | KnowledgeCategory) => void
  onEdit: (document: KnowledgeDocument) => void
  onAction: (document: KnowledgeDocument, action: 'approve' | 'activate' | 'archive' | 'reindex') => void
}

const categories: Array<'ALL' | KnowledgeCategory> = ['ALL', 'Company', 'Services', 'Franchise', 'Policies', 'FAQ', 'System']
const statuses: Array<'ALL' | KnowledgeStatus> = ['ALL', 'DRAFT', 'APPROVED', 'ACTIVE', 'ARCHIVED']

export function KnowledgeTable({ documents, query, onQueryChange, status, onStatusChange, category, onCategoryChange, onEdit, onAction }: KnowledgeTableProps) {
  const filtered = documents.filter((document) => {
    const matchesQuery = `${document.id} ${document.title} ${document.content}`.toLowerCase().includes(query.toLowerCase())
    return matchesQuery && (status === 'ALL' || document.status === status) && (category === 'ALL' || document.category === category)
  })
  return (
    <section className="knowledge-table-card">
      <div className="table-toolbar"><div className="table-search"><span>⌕</span><input value={query} onChange={(event) => onQueryChange(event.target.value)} placeholder="Search documents, IDs, or content…" aria-label="Search knowledge documents" /></div><div className="table-filters"><select value={category} onChange={(event) => onCategoryChange(event.target.value as 'ALL' | KnowledgeCategory)} aria-label="Filter by category">{categories.map((item) => <option key={item} value={item}>{item === 'ALL' ? 'All categories' : item}</option>)}</select><select value={status} onChange={(event) => onStatusChange(event.target.value as 'ALL' | KnowledgeStatus)} aria-label="Filter by status">{statuses.map((item) => <option key={item} value={item}>{item === 'ALL' ? 'All statuses' : item}</option>)}</select></div></div>
      <div className="table-summary"><span><strong>{filtered.length}</strong> of {documents.length} documents</span><span>Retrieval filter: <strong>APPROVED + ACTIVE</strong></span></div>
      <div className="knowledge-table-wrap"><table className="knowledge-table"><thead><tr><th>Document</th><th>Category</th><th>Version</th><th>Status</th><th>Updated</th><th>Actions</th></tr></thead><tbody>{filtered.map((document) => <tr key={document.id}><td><div className="document-cell"><span className="document-icon">▧</span><span><strong>{document.title}</strong><small>{document.id} · {document.source.replace('internal://', '')}</small></span></div></td><td><span className="category-text">{document.category}</span></td><td><span className="version-text">v{document.version}</span></td><td><StatusBadge status={document.status} /></td><td><span className="updated-text">{new Date(document.updatedAt).toLocaleDateString([], { month: 'short', day: '2-digit', year: 'numeric' })}</span></td><td><div className="row-actions"><Button variant="ghost" size="sm" onClick={() => onEdit(document)}>Edit</Button>{document.status === 'DRAFT' && <Button variant="subtle" size="sm" onClick={() => onAction(document, 'approve')}>Approve</Button>}{document.status === 'APPROVED' && <Button variant="subtle" size="sm" onClick={() => onAction(document, 'activate')}>Activate</Button>}{document.status === 'ACTIVE' && <Button variant="danger" size="sm" onClick={() => onAction(document, 'archive')}>Archive</Button>}<Button variant="ghost" size="sm" onClick={() => onAction(document, 'reindex')}>Reindex</Button></div></td></tr>)}</tbody></table>{filtered.length === 0 && <div className="table-empty"><span>⌁</span><strong>No matching documents</strong><p>Try a different filter or create a new approved knowledge document.</p></div>}</div>
    </section>
  )
}
