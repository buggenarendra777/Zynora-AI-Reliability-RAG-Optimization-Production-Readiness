import type { KnowledgeStatus } from '../../types/zynora'

export function StatusBadge({ status }: { status: KnowledgeStatus }) {
  return <span className={`status-badge status-${status.toLowerCase()}`}><span className="status-dot" />{status}</span>
}
