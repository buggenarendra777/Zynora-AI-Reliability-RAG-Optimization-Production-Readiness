import { useEffect, useState } from 'react'
import type { KnowledgeCategory, KnowledgeDocument, KnowledgeStatus } from '../../types/zynora'
import { Button } from '../common/Button'

interface KnowledgeEditorProps {
  document: KnowledgeDocument | null
  onSave: (document: KnowledgeDocument) => void
  onCancel: () => void
}

const categories: KnowledgeCategory[] = ['Company', 'Services', 'Franchise', 'Policies', 'FAQ', 'System']

export function KnowledgeEditor({ document, onSave, onCancel }: KnowledgeEditorProps) {
  const [draft, setDraft] = useState<KnowledgeDocument>(document ?? { id: '', title: '', category: 'Company', content: '', source: 'internal://approved/', version: '1.0', status: 'DRAFT', updatedAt: new Date().toISOString() })
  useEffect(() => { setDraft(document ?? { id: '', title: '', category: 'Company', content: '', source: 'internal://approved/', version: '1.0', status: 'DRAFT', updatedAt: new Date().toISOString() }) }, [document])
  const update = <K extends keyof KnowledgeDocument>(key: K, value: KnowledgeDocument[K]) => setDraft((current) => ({ ...current, [key]: value }))
  const submit = (event: React.FormEvent) => { event.preventDefault(); if (!draft.title.trim() || !draft.content.trim()) return; const id = draft.id || `KB-LOCAL-${Date.now()}`; onSave({ ...draft, id, title: draft.title.trim(), content: draft.content.trim(), updatedAt: new Date().toISOString() }) }
  return <div className="editor-modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.currentTarget === event.target) onCancel() }}><section className="editor-modal" role="dialog" aria-modal="true" aria-label={document ? 'Edit knowledge document' : 'Add knowledge document'}><div className="editor-heading"><div><span className="eyebrow">{document ? 'Edit record' : 'New record'}</span><h2>{document ? document.title : 'Add knowledge document'}</h2></div><button className="close-button" onClick={onCancel} aria-label="Close editor">×</button></div><form onSubmit={submit}><div className="editor-grid"><label>Title<input value={draft.title} onChange={(event) => update('title', event.target.value)} placeholder="Document title" required /></label><label>Category<select value={draft.category} onChange={(event) => update('category', event.target.value as KnowledgeCategory)}>{categories.map((category) => <option key={category}>{category}</option>)}</select></label><label>Version<input value={draft.version} onChange={(event) => update('version', event.target.value)} placeholder="1.0" required /></label><label>Status<select value={draft.status} onChange={(event) => update('status', event.target.value as KnowledgeStatus)}><option>DRAFT</option><option>APPROVED</option><option>ACTIVE</option><option>ARCHIVED</option></select></label></div><label>Source<input value={draft.source} onChange={(event) => update('source', event.target.value)} placeholder="internal://approved/category/KB000.md" required /></label><label>Approved content<textarea value={draft.content} onChange={(event) => update('content', event.target.value)} placeholder="Enter only approved Zyngram knowledge content…" rows={8} required /></label><div className="editor-note"><span>⌑</span>Only approved Zyngram content should be entered. External URLs and unapproved claims are not permitted.</div><div className="editor-actions"><Button type="button" variant="ghost" onClick={onCancel}>Cancel</Button><Button type="submit" variant="primary">Save document</Button></div></form></section></div>
}
