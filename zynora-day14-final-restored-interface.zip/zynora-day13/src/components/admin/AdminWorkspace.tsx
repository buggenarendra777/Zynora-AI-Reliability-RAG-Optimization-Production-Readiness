import { useMemo, useState } from 'react'
import type { AuditEvent, KnowledgeDocument, KnowledgeStatus } from '../../types/zynora'
import { Button } from '../common/Button'
import { KnowledgeEditor } from './KnowledgeEditor'
import { KnowledgeTable } from './KnowledgeTable'

interface AdminWorkspaceProps {
  documents: KnowledgeDocument[]
  onDocumentsChange: (documents: KnowledgeDocument[]) => void
  audits: AuditEvent[]
  onAudit: (event: AuditEvent) => void
}

export function AdminWorkspace({ documents, onDocumentsChange, audits, onAudit }: AdminWorkspaceProps) {
  const [query, setQuery] = useState('')
  const [status, setStatus] = useState<'ALL' | KnowledgeStatus>('ALL')
  const [category, setCategory] = useState<'ALL' | KnowledgeDocument['category']>('ALL')
  const [editing, setEditing] = useState<KnowledgeDocument | null>(null)
  const [editorOpen, setEditorOpen] = useState(false)
  const [toast, setToast] = useState('')
  const activeCount = useMemo(() => documents.filter((document) => document.status === 'APPROVED' || document.status === 'ACTIVE').length, [documents])
  const recordAudit = (action: string, detail: string, documentId?: string) => { onAudit({ id: `audit-${Date.now()}`, action, detail, documentId, createdAt: new Date().toISOString() }); setToast(detail); window.setTimeout(() => setToast(''), 2200) }
  const saveDocument = (document: KnowledgeDocument) => { const exists = documents.some((item) => item.id === document.id); onDocumentsChange(exists ? documents.map((item) => item.id === document.id ? document : item) : [document, ...documents]); recordAudit(exists ? 'EDIT_DOCUMENT' : 'CREATE_DOCUMENT', `${exists ? 'Updated' : 'Created'} ${document.id}`, document.id); setEditorOpen(false); setEditing(null) }
  const handleAction = (document: KnowledgeDocument, action: 'approve' | 'activate' | 'archive' | 'reindex') => { if (action === 'reindex') { recordAudit('REINDEX_DOCUMENT', `Reindexed ${document.id}`, document.id); return } const next: Record<'approve' | 'activate' | 'archive', KnowledgeStatus> = { approve: 'APPROVED', activate: 'ACTIVE', archive: 'ARCHIVED' }; const nextStatus = next[action]; const allowed = (action === 'approve' && document.status === 'DRAFT') || (action === 'activate' && document.status === 'APPROVED') || (action === 'archive' && document.status === 'ACTIVE'); if (!allowed) { recordAudit('BLOCKED_STATUS_CHANGE', `Blocked invalid ${document.status} → ${nextStatus} transition for ${document.id}`, document.id); return } onDocumentsChange(documents.map((item) => item.id === document.id ? { ...item, status: nextStatus, updatedAt: new Date().toISOString() } : item)); recordAudit(`${action.toUpperCase()}_DOCUMENT`, `${document.id} moved to ${nextStatus}`, document.id) }
  return <main className="admin-page"><div className="admin-heading"><div><span className="eyebrow">Knowledge operations</span><h1>Approved content control room.</h1><p>Manage the documents Zynora is permitted to retrieve. This local preview mirrors the future authorized admin API.</p></div><Button variant="primary" onClick={() => { setEditing(null); setEditorOpen(true) }} icon="+">Add document</Button></div><div className="admin-metrics"><div><span className="metric-label">Total documents</span><strong>{documents.length}</strong><small>Across all statuses</small></div><div><span className="metric-label">Retrievable now</span><strong>{activeCount}</strong><small>Approved + active only</small></div><div><span className="metric-label">Audit events</span><strong>{audits.length}</strong><small>Local activity trail</small></div><div className="admin-preview-chip"><span className="pulse-dot" /><div><strong>Local preview</strong><small>Auth + MySQL connect later</small></div></div></div><KnowledgeTable documents={documents} query={query} onQueryChange={setQuery} status={status} onStatusChange={setStatus} category={category} onCategoryChange={setCategory} onEdit={(document) => { setEditing(document); setEditorOpen(true) }} onAction={handleAction} /><section className="audit-card"><div className="audit-heading"><div><span className="eyebrow">Audit trail</span><h2>Recent knowledge actions</h2></div><span className="audit-lock">Admin events only</span></div>{audits.length === 0 ? <p className="audit-empty">No local actions yet. Create, approve, activate, archive, or reindex a document to see the trail.</p> : <div className="audit-list">{audits.slice(0, 6).map((event) => <div className="audit-item" key={event.id}><span className="audit-marker" /><div><strong>{event.action.replaceAll('_', ' ')}</strong><p>{event.detail}</p></div><time>{new Date(event.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</time></div>)}</div>}</section>{editorOpen && <KnowledgeEditor document={editing} onSave={saveDocument} onCancel={() => { setEditorOpen(false); setEditing(null) }} />}{toast && <div className="toast"><span className="pulse-dot" />{toast}</div>}</main>
}
