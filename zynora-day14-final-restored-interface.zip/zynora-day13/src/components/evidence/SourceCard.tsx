import type { SourceReference } from '../../types/zynora'

export function SourceCard({ source }: { source: SourceReference }) {
  return (
    <div className="source-card">
      <div className="source-card-icon">↗</div>
      <div className="source-card-copy">
        <strong>{source.title}</strong>
        <span>{source.documentId} · v{source.version}</span>
        <small>{source.category} · {source.source.replace('internal://approved/', '')}</small>
      </div>
    </div>
  )
}
