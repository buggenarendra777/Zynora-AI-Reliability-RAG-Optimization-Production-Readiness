import { useState } from 'react'
import type { RetrievedChunk } from '../../types/zynora'

export function RetrievedChunkCard({ chunk }: { chunk: RetrievedChunk }) {
  const [expanded, setExpanded] = useState(false)
  return (
    <div className={`chunk-card ${expanded ? 'chunk-card-expanded' : ''}`}>
      <button className="chunk-card-toggle" onClick={() => setExpanded((value) => !value)} aria-expanded={expanded}>
        <span className="chunk-index">{chunk.chunkId}</span>
        <span className="chunk-heading"><strong>{chunk.section}</strong><small>{Math.round(chunk.score * 100)}% match</small></span>
        <span className="chevron">{expanded ? '⌃' : '⌄'}</span>
      </button>
      {expanded && <p className="chunk-content">{chunk.content}</p>}
    </div>
  )
}
