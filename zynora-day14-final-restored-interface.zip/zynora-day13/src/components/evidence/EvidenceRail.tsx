import type { ChatMessage } from '../../types/zynora'
import { SourceCard } from './SourceCard'
import { RetrievedChunkCard } from './RetrievedChunkCard'

interface EvidenceRailProps {
  message: ChatMessage | null
  mobileOpen: boolean
  onToggleMobile: () => void
}

export function EvidenceRail({ message, mobileOpen, onToggleMobile }: EvidenceRailProps) {
  const grounded = Boolean(message?.grounded && message.sources?.length)
  return (
    <aside className={`evidence-rail ${mobileOpen ? 'evidence-rail-open' : ''}`}>
      <div className="evidence-rail-heading">
        <div>
          <span className="eyebrow">Traceability</span>
          <h2>Evidence used</h2>
        </div>
        <button className="mobile-rail-toggle" onClick={onToggleMobile} aria-label="Toggle evidence panel">{mobileOpen ? '×' : '↗'}</button>
      </div>
      {!message ? (
        <div className="evidence-empty">
          <div className="evidence-empty-mark">◌</div>
          <strong>Select an answer</strong>
          <p>Retrieved chunks and source metadata will appear here when Zynora answers.</p>
        </div>
      ) : grounded ? (
        <div className="evidence-content">
          <div className="evidence-summary"><span className="pulse-dot" />Grounded in approved content</div>
          <div className="evidence-section"><span className="eyebrow">Sources</span>{message.sources?.map((source) => <SourceCard key={`${source.documentId}-${source.version}`} source={source} />)}</div>
          <div className="evidence-section"><span className="eyebrow">Retrieved chunks</span>{message.retrievedChunks?.map((chunk) => <RetrievedChunkCard key={chunk.chunkId} chunk={chunk} />)}</div>
        </div>
      ) : (
        <div className="evidence-empty evidence-empty-warning">
          <div className="evidence-empty-mark">!</div>
          <strong>No approved evidence found</strong>
          <p>This response is intentionally not grounded because the approved knowledge base did not contain the answer.</p>
        </div>
      )}
      <div className="evidence-rail-footer"><span className="lock-icon">⌑</span><span>External sources disabled</span></div>
    </aside>
  )
}
