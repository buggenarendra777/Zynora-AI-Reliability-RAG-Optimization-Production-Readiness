import { useState } from 'react'
import type { ChatMessage } from '../../types/zynora'
import { ZynoraMark } from '../brand/ZynoraMark'

interface MessageBubbleProps {
  message: ChatMessage
  selected: boolean
  onSelectEvidence: () => void
  onCopy: (content: string) => void
}

export function MessageBubble({ message, selected, onSelectEvidence, onCopy }: MessageBubbleProps) {
  const [copied, setCopied] = useState(false)
  const isAssistant = message.role === 'assistant'
  const time = new Date(message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  const copy = () => {
    onCopy(message.content)
    setCopied(true)
    window.setTimeout(() => setCopied(false), 1400)
  }

  return (
    <article className={`message-row message-row-${message.role} ${selected ? 'message-row-selected' : ''}`}>
      {isAssistant && <div className="message-avatar"><ZynoraMark compact /></div>}
      <div className="message-column">
        <div className={`message-bubble ${message.error ? 'message-bubble-error' : ''}`}>
          {isAssistant && <div className="message-label"><strong>Zynora</strong><span>·</span><span>{message.grounded && message.sources?.length ? 'Grounded answer' : 'Knowledge-base response'}</span></div>}
          <p>{message.content}</p>
          {isAssistant && message.grounded && message.sources && message.sources.length > 0 && <button className="inline-evidence-button" onClick={onSelectEvidence}><span className="pulse-dot" />{message.sources.length} approved source{message.sources.length > 1 ? 's' : ''} · View evidence ↗</button>}
        </div>
        <div className="message-meta"><span>{time}</span>{isAssistant && <button onClick={copy}>{copied ? 'Copied' : 'Copy answer'}</button>}</div>
      </div>
    </article>
  )
}
