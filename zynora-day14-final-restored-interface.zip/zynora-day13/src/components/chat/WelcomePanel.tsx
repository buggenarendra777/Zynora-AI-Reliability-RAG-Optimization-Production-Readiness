interface WelcomePanelProps {
  onPrompt: (prompt: string) => void
}

const prompts = [
  { label: 'Company scope', text: 'What is Zyngram?' },
  { label: 'Franchise', text: 'What is the physical franchise hierarchy?' },
  { label: 'Services', text: 'What approved services are included?' },
]

export function WelcomePanel({ onPrompt }: WelcomePanelProps) {
  return (
    <section className="welcome-panel">
      <div className="welcome-kicker"><span className="pulse-dot" />Approved knowledge mode</div>
      <h1>Ask the approved<br /><span>Zyngram knowledge base.</span></h1>
      <p>Every answer is backed by content your team approved. Zynora will never guess, browse, or use an external source.</p>
      <div className="suggested-prompts">{prompts.map((prompt) => <button key={prompt.text} className="suggested-prompt" onClick={() => onPrompt(prompt.text)}><span>{prompt.label}</span><strong>{prompt.text}</strong><span className="prompt-arrow">↗</span></button>)}</div>
      <div className="welcome-note"><span className="shield-icon">◇</span><span>RAG-only by design · Source traceability on every grounded answer</span></div>
    </section>
  )
}
