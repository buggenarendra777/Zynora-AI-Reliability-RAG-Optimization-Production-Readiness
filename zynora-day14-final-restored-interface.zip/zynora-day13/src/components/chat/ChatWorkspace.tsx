import type { ChatMessage } from '../../types/zynora'
import { ConversationList } from './ConversationList'
import { Composer } from './Composer'
import { MessageBubble } from './MessageBubble'
import { WelcomePanel } from './WelcomePanel'

interface ChatWorkspaceProps {
  messages: ChatMessage[]
  input: string
  onInputChange: (value: string) => void
  onSend: () => void
  onClear: () => void
  loading: boolean
  error: string | null
  selectedMessageId: string | null
  onSelectMessage: (message: ChatMessage) => void
  onCopy: (content: string) => void
  onPrompt: (prompt: string) => void
}

export function ChatWorkspace({ messages, input, onInputChange, onSend, onClear, loading, error, selectedMessageId, onSelectMessage, onCopy, onPrompt }: ChatWorkspaceProps) {
  const hasUserMessages = messages.some((message) => message.role === 'user')
  return (
    <main className="chat-page">
      <div className="chat-sidebar-column"><ConversationList messages={messages} onSelectThread={() => document.querySelector('.chat-scroll')?.scrollTo({ top: 0, behavior: 'smooth' })} /><div className="chat-sidebar-rule"><span />No web search<span /></div></div>
      <section className="chat-content">
        <div className="chat-scroll">
          {!hasUserMessages && <WelcomePanel onPrompt={onPrompt} />}
          <div className="message-stack">{messages.map((message) => <MessageBubble key={message.id} message={message} selected={selectedMessageId === message.id} onSelectEvidence={() => onSelectMessage(message)} onCopy={onCopy} />)}{loading && <div className="message-row message-row-assistant"><div className="message-avatar"><span className="mini-z">Z</span></div><div className="message-column"><div className="message-bubble loading-bubble"><div className="message-label"><strong>Zynora</strong><span>·</span><span>Retrieving approved context</span></div><div className="typing-dots"><i /><i /><i /></div></div></div></div>}</div>
          {error && <div className="inline-error"><span>!</span>{error}</div>}
        </div>
        <div className="composer-wrap"><Composer value={input} onChange={onInputChange} onSubmit={onSend} loading={loading} /><div className="composer-disclaimer"><span>⌑</span>Zynora answers from approved Zyngram content only.<button onClick={onClear}>Reset this conversation</button></div></div>
      </section>
    </main>
  )
}
