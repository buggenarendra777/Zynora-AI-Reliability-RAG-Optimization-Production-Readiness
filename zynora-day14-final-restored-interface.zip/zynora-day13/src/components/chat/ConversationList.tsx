import type { ChatMessage } from '../../types/zynora'

interface ConversationListProps {
  messages: ChatMessage[]
  onSelectThread: () => void
}

export function ConversationList({ messages, onSelectThread }: ConversationListProps) {
  const lastQuestion = [...messages].reverse().find((message) => message.role === 'user')
  return (
    <div className="conversation-list">
      <div className="conversation-list-heading"><span className="eyebrow">Workspace</span><span className="conversation-count">{messages.filter((message) => message.role === 'user').length} asks</span></div>
      <button className="conversation-item conversation-item-active" onClick={onSelectThread}>
        <span className="conversation-status" />
        <span className="conversation-item-copy"><strong>Current conversation</strong><small>{lastQuestion?.content || 'Approved knowledge exploration'}</small></span>
        <span className="conversation-more">•••</span>
      </button>
      <div className="conversation-tip"><span>⌁</span><p>Start with a suggested question or ask about any approved Zyngram topic.</p></div>
    </div>
  )
}
