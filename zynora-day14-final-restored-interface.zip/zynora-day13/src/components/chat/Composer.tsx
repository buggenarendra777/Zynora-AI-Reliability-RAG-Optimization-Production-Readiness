import { useEffect, useRef } from 'react'
import { Button } from '../common/Button'

interface ComposerProps {
  value: string
  onChange: (value: string) => void
  onSubmit: () => void
  loading: boolean
  disabled?: boolean
}

export function Composer({ value, onChange, onSubmit, loading, disabled = false }: ComposerProps) {
  const inputRef = useRef<HTMLTextAreaElement>(null)
  useEffect(() => { inputRef.current?.focus() }, [])
  const canSend = value.trim().length > 0 && !loading && !disabled

  return (
    <form className="composer" onSubmit={(event) => { event.preventDefault(); if (canSend) onSubmit() }}>
      <textarea ref={inputRef} value={value} onChange={(event) => onChange(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); if (canSend) onSubmit() } }} placeholder="Ask about approved Zyngram content…" rows={1} maxLength={1000} aria-label="Ask Zynora a question" disabled={disabled || loading} />
      <div className="composer-footer"><span className="composer-hint">Enter to send · Shift + Enter for a new line</span><span className="composer-count">{value.length}/1000</span><Button type="submit" variant="primary" size="md" disabled={!canSend} icon={loading ? <span className="button-spinner" /> : '↑'}>{loading ? 'Searching' : 'Ask Zynora'}</Button></div>
    </form>
  )
}
