import { existsSync } from 'node:fs'
import { spawnSync } from 'node:child_process'
import path from 'node:path'

const root = process.cwd()
const candidates = process.platform === 'win32'
  ? [path.join(root, '.venv', 'Scripts', 'python.exe'), 'py', 'python']
  : [path.join(root, '.venv', 'bin', 'python'), 'python3', 'python']
const python = candidates.find((candidate) => candidate === 'py' || candidate === 'python' || candidate === 'python3' || existsSync(candidate))

if (!python) {
  console.error('FAIL: Python was not found. Create .venv and install backend\\requirements.txt first.')
  process.exit(1)
}

const script = path.join(root, 'scripts', 'day13_console.py')
const result = spawnSync(python, [script], { stdio: 'inherit', shell: python === 'py' })
process.exit(result.status ?? 1)
